const { search, searchPhotos, searchNearby, locationReviews, details } = require('../services/controller');

module.exports = {
    search,
    searchPhotos,
    searchNearby,
    locationReviews,
    details
}
