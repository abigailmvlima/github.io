const details = require('./details.json');
const nearby = require('./nearby.json');
const photos = require('./photos.json');
const reviews = require('./reviews.json');
const search = require('./search.json');

module.exports = {
    details,
    nearby,
    photos,
    reviews,
    search
}