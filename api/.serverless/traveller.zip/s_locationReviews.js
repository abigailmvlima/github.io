
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'elioglima',
  applicationName: 'aws-node-express-api-app',
  appUid: 'jjSXX4Tlf9ZzRnJZyW',
  orgUid: 'dcdd13ac-ea9f-4b7b-b293-fcfe1e00ef4c',
  deploymentUid: '6492c518-22a7-4cf8-897b-737995168458',
  serviceName: 'traveller',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'traveller-dev-locationReviews', timeout: 30 };

try {
  const userHandler = require('./src/lambda/controller.js');
  module.exports.handler = serverlessSDK.handler(userHandler.locationReviews, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}