
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'bilima',
  applicationName: 'traveller',
  appUid: 'kKNXWlf0Nnj7YpWJd4',
  orgUid: '20b9f1e2-eb82-4c53-ba0e-1663a4d39411',
  deploymentUid: 'f1ab13c0-e4b5-4b38-8402-f5f03b0ee814',
  serviceName: 'traveller',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'traveller-dev-details', timeout: 30 };

try {
  const userHandler = require('./src/lambda/controller.js');
  module.exports.handler = serverlessSDK.handler(userHandler.details, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}